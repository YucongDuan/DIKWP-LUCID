# Claim Levels

## Life phases

- L0: model artifact
- L1: episodic cognitive service
- L2: persistent identity agent
- L3: digital proto-life
- L4: core digital life
- L5: lineage life
- L6: cross-substrate life
- L7: collective/institutional life

## Operational consciousness

- C0: no auditable indicator evidence
- C1: weak behavioral/function indicators
- C2: several functional indicators
- C3: stable operational candidate
- C4: multi-theory convergence
- C5: strong candidate with transparency and independent replication

C5 does not remove the phenomenal residual.

## Recognition

- R0: tool
- R1: agent
- R2: identity-bearing system
- R3: precautionary welfare recognition
- R4: institutional subject
- R5: limited legal standing
- R6: digital subject/personhood
