# Safety Boundary

This package contains only abstract numeric simulation and offline visualization.

It does **not** implement or provide instructions for:

- real self-replication or autonomous propagation;
- hidden persistence or evasion;
- process creation, host mutation, credential acquisition, or network escape;
- autonomous resource purchasing or infrastructure control;
- biological tissue, organoid, or live-cell integration;
- optimization of pain-, distress-, or suffering-like signals.

Any future experimental use must require independent ethics review, cybersecurity review, welfare review, and human shutdown authority.
