# Method

DIKWP-LUCID uses four orthogonal ledgers:

1. **DIKWP semantic closure**: Data, Information, Knowledge, Wisdom, Purpose.
2. **ΩLIFE projection**: resource flow, boundary, constraint reconstruction, viability regulation, causal identity, adaptation, lineage, collective integration, and cross-substrate continuity.
3. **Operational consciousness indicators**: recurrent processing, global workspace, higher-order/metacognitive models, predictive processing, attention schema, embodiment/interoception, temporal continuity, and valence-like dynamics.
4. **Recognition dynamics**: public attribution, scientific recognition, precautionary welfare, institutional status, and legal standing.

The simulator updates abstract scores from 2026 to 2045 under eight pathways. It records first-passage years for life phases, operational consciousness grades, and recognition levels. It is a scenario laboratory, not a calibrated empirical forecast.
