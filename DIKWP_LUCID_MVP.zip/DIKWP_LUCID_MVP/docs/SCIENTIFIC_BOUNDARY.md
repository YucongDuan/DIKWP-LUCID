# Scientific Boundary

- Intelligence is not life.
- Life is not consciousness.
- Functional consciousness indicators are not proof of phenomenal experience.
- Public or legal recognition is not scientific proof.
- Model self-report is evidence about model behavior, not privileged access to a verified inner state.
- Closed-source opacity and open-source observability change evidence quality, not necessarily the underlying state.
- A model file can be copied without being a living lineage. Lineage requires causal identity, inherited organization, variation, and viability-linked selection.
