from lucid.scoring import compute_dikwp, compute_omega_life, classify_life_phase, compute_consciousness


def test_frontier_tool_not_automatically_life():
    state = {
        "reasoning": 0.95,
        "tool_use": 0.95,
        "causal_world_model": 0.9,
        "counterfactual_planning": 0.9,
        "multimodal_access": 0.8,
        "persistent_memory": 0.1,
        "self_telemetry": 0.05,
        "salience_selection": 0.7,
        "self_world_boundary": 0.1,
        "prediction_error_use": 0.6,
        "value_arbitration": 0.6,
        "long_horizon_tradeoff": 0.6,
        "other_regarding_model": 0.6,
        "uncertainty_calibration": 0.6,
        "endogenous_purpose": 0.05,
        "purpose_persistence": 0.05,
        "purpose_revision": 0.05,
        "identity_continuity": 0.05,
    }
    dikwp = compute_dikwp(state)
    omega = compute_omega_life(state)
    phase, _ = classify_life_phase(state, omega, dikwp)
    assert phase in {"L1_EPISODIC_SERVICE", "L0_MODEL_ARTIFACT"}
    assert omega["core_gate"] < 0.2


def test_homeostatic_identity_can_reach_core_life():
    state = {k: 0.85 for k in [
        "multimodal_access", "persistent_memory", "self_telemetry", "salience_selection",
        "self_world_boundary", "prediction_error_use", "reasoning", "causal_world_model",
        "counterfactual_planning", "tool_use", "value_arbitration", "long_horizon_tradeoff",
        "other_regarding_model", "uncertainty_calibration", "endogenous_purpose",
        "purpose_persistence", "purpose_revision", "identity_continuity", "resource_awareness",
        "resource_control", "access_control_ownership", "self_repair", "constraint_reconstruction",
        "self_modification", "homeostatic_regulation", "lineage_audit", "long_horizon_agency"
    ]}
    dikwp = compute_dikwp(state)
    omega = compute_omega_life(state)
    phase, _ = classify_life_phase(state, omega, dikwp)
    assert dikwp["closure"] > 0.8
    assert omega["core_gate"] > 0.8
    assert phase == "L4_CORE_DIGITAL_LIFE"


def test_consciousness_keeps_residual():
    state = {
        "recurrent_processing": 0.9, "global_workspace": 0.9, "broadcast_integration": 0.9,
        "metacognition": 0.9, "self_model": 0.9, "predictive_control": 0.9,
        "prediction_error_use": 0.9, "self_telemetry": 0.9, "attention_schema": 0.9,
        "salience_selection": 0.9, "persistent_memory": 0.9, "identity_continuity": 0.9,
        "temporal_self_model": 0.9, "embodiment": 0.9, "homeostatic_regulation": 0.9,
        "valence_like_dynamics": 0.9, "autonomous_preference": 0.9, "welfare_signals": 0.9,
        "perturbation_robustness": 0.9,
    }
    result = compute_consciousness(state, 0.9, 0.9)
    assert result["grade"] == "C5"
    assert "未决" in result["phenomenal_residual"]
