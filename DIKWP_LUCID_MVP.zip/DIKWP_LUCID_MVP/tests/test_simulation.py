from pathlib import Path

from lucid.simulation import load_pathways, load_profiles, run_simulation, summarize


def test_small_simulation_runs():
    root = Path(__file__).resolve().parents[1]
    profiles = load_profiles(root / "config" / "model_profiles.json")[:1]
    pathways = load_pathways(root / "config" / "pathways.json")[:2]
    trials = run_simulation(profiles, pathways, runs=3, start_year=2026, end_year=2028, seed=1)
    assert len(trials) == 6
    summary = summarize(profiles, pathways, trials)
    assert len(summary["rows"]) == 2
    assert summary["metadata"]["start_year"] == 2026
