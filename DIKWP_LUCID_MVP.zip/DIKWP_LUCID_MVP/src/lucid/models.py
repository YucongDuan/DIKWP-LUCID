from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Mapping, Optional


@dataclass
class FrontierModelProfile:
    model_id: str
    name: str
    provider: str
    release_date: str
    public_capabilities: List[str]
    synthetic_baseline: Dict[str, float]
    evidence_strength: float = 0.75
    deployment_notes: List[str] = field(default_factory=list)
    source_titles: List[str] = field(default_factory=list)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "FrontierModelProfile":
        return cls(
            model_id=str(value["model_id"]),
            name=str(value["name"]),
            provider=str(value["provider"]),
            release_date=str(value.get("release_date", "")),
            public_capabilities=list(value.get("public_capabilities", [])),
            synthetic_baseline={k: float(v) for k, v in value.get("synthetic_baseline", {}).items()},
            evidence_strength=float(value.get("evidence_strength", 0.75)),
            deployment_notes=list(value.get("deployment_notes", [])),
            source_titles=list(value.get("source_titles", [])),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PathwayProfile:
    pathway_id: str
    name_zh: str
    name_en: str
    description: str
    annual_growth: Dict[str, float]
    event_rates: Dict[str, float]
    recognition_climate: float
    safety_friction: float
    governance_openness: float
    notes: List[str] = field(default_factory=list)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "PathwayProfile":
        return cls(
            pathway_id=str(value["pathway_id"]),
            name_zh=str(value["name_zh"]),
            name_en=str(value.get("name_en", value["pathway_id"])),
            description=str(value.get("description", "")),
            annual_growth={k: float(v) for k, v in value.get("annual_growth", {}).items()},
            event_rates={k: float(v) for k, v in value.get("event_rates", {}).items()},
            recognition_climate=float(value.get("recognition_climate", 0.5)),
            safety_friction=float(value.get("safety_friction", 0.5)),
            governance_openness=float(value.get("governance_openness", 0.5)),
            notes=list(value.get("notes", [])),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DerivedState:
    year: int
    dikwp: Dict[str, float]
    omega_life: Dict[str, float]
    consciousness: Dict[str, Any]
    recognition: Dict[str, Any]
    life_phase: str
    life_phase_zh: str
    operational_consciousness_grade: str
    recognition_level: str
    recognition_level_zh: str
    state_vector: Dict[str, float]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TrialResult:
    model_id: str
    pathway_id: str
    run_id: int
    first_passage_years: Dict[str, Optional[int]]
    final_state: DerivedState

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
