from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .models import FrontierModelProfile, PathwayProfile
from .scoring import compute_consciousness, compute_dikwp, compute_omega_life, classify_life_phase, compute_recognition
from .simulation import baseline_state


def baseline_cards(profiles: Iterable[FrontierModelProfile], pathways: Iterable[PathwayProfile]) -> List[Dict[str, Any]]:
    default_pathway = list(pathways)[0]
    cards = []
    for profile in profiles:
        state = baseline_state(profile)
        dikwp = compute_dikwp(state)
        omega = compute_omega_life(state)
        life_phase, life_phase_zh = classify_life_phase(state, omega, dikwp)
        consciousness = compute_consciousness(state, state.get("transparency", 0.0), state.get("independent_replication", 0.0))
        recognition = compute_recognition(state, consciousness, default_pathway.recognition_climate, default_pathway.governance_openness)
        cards.append({
            "model_id": profile.model_id,
            "name": profile.name,
            "provider": profile.provider,
            "release_date": profile.release_date,
            "capabilities": profile.public_capabilities,
            "dikwp": dikwp,
            "omega_life": omega,
            "life_phase": life_phase,
            "life_phase_zh": life_phase_zh,
            "consciousness": consciousness,
            "recognition": recognition,
            "notes": profile.deployment_notes,
            "sources": profile.source_titles,
        })
    return cards


def render_dashboard(
    output_path: Path,
    profiles: List[FrontierModelProfile],
    pathways: List[PathwayProfile],
    summary: Dict[str, Any],
) -> None:
    payload = {
        "profiles": [p.to_dict() for p in profiles],
        "pathways": [p.to_dict() for p in pathways],
        "baseline_cards": baseline_cards(profiles, pathways),
        "summary": summary,
    }
    data_json = json.dumps(payload, ensure_ascii=False)
    template = r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>DIKWP-LUCID 前沿AI生命化与意识承认路径模拟系统</title>
<style>
:root{--bg:#07101b;--panel:#0f1b2b;--panel2:#13243a;--text:#eef5ff;--muted:#9fb0c7;--line:#25425f;--accent:#7cc4ff;--good:#7de2b8;--warn:#ffd37c;--bad:#ff9d9d}
*{box-sizing:border-box}body{margin:0;background:linear-gradient(180deg,#07101b,#0b1421 45%,#07101b);font-family:Inter,Segoe UI,Arial,"Microsoft YaHei",sans-serif;color:var(--text)}
header{padding:34px 5vw 18px;border-bottom:1px solid var(--line);background:rgba(4,12,22,.85);position:sticky;top:0;z-index:2;backdrop-filter:blur(12px)}
h1{font-size:clamp(26px,4vw,46px);margin:0 0 9px;letter-spacing:.5px}.sub{color:var(--muted);max-width:1100px;line-height:1.7}
main{padding:24px 5vw 60px;max-width:1600px;margin:auto}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px}.panel{background:linear-gradient(145deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:16px;padding:18px;box-shadow:0 12px 34px rgba(0,0,0,.24)}
.controls{grid-column:span 12;display:flex;gap:14px;flex-wrap:wrap;align-items:end}.control{display:flex;flex-direction:column;gap:6px;min-width:240px}.control label{color:var(--muted);font-size:13px}select{background:#0a1624;color:var(--text);border:1px solid var(--line);padding:10px 12px;border-radius:9px;font-size:15px}
.kpis{grid-column:span 12;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px}.kpi{padding:14px;border:1px solid var(--line);border-radius:12px;background:rgba(2,10,18,.35)}.kpi .v{font-size:29px;font-weight:700}.kpi .l{font-size:12px;color:var(--muted);margin-top:5px}
.half{grid-column:span 6}.third{grid-column:span 4}.full{grid-column:span 12}.title{font-size:18px;font-weight:700;margin-bottom:12px}.muted{color:var(--muted)}
.bar{height:10px;background:#07111d;border-radius:999px;overflow:hidden;border:1px solid #203b55}.bar>span{display:block;height:100%;background:linear-gradient(90deg,#4fb2ff,#8ae0c1)}
.metric{margin:10px 0}.metric-head{display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px}.pill{display:inline-block;padding:5px 9px;border-radius:999px;background:#16304a;border:1px solid #2f5579;margin:3px 4px 3px 0;font-size:12px;color:#d7e9fa}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px 7px;border-bottom:1px solid var(--line);text-align:left}th{color:#bcd2e8;position:sticky;top:114px;background:#0f1b2b}.prob{font-variant-numeric:tabular-nums}
.timeline{width:100%;height:280px;background:#081522;border:1px solid var(--line);border-radius:12px}.legend{display:flex;gap:14px;flex-wrap:wrap;margin:10px 0;color:var(--muted);font-size:12px}.dot{width:10px;height:10px;border-radius:50%;display:inline-block;margin-right:5px}
.path-card{border-left:4px solid #66b9f0;padding-left:12px;margin:12px 0}.path-card b{display:block;margin-bottom:5px}.notice{border:1px solid #6d5c2c;background:#2a2414;color:#ffe6a6;padding:12px 14px;border-radius:10px;line-height:1.65}
@media(max-width:1000px){.half,.third{grid-column:span 12}.kpis{grid-template-columns:repeat(2,minmax(0,1fr))}th{position:static}}@media(max-width:560px){main,header{padding-left:16px;padding-right:16px}.kpis{grid-template-columns:1fr}.control{min-width:100%}}
</style>
</head>
<body>
<header><h1>DIKWP-LUCID</h1><div class="sub">前沿AI生命化与意识承认路径模拟系统。它把“能力强”拆成DIKWP语义闭环、ΩLIFE生命闭环、多理论意识指标与社会/制度承认四条相互独立的轨道。所有数值均为可修改的合成先验，不是对任何模型内部状态的断言。</div></header>
<main>
<div class="grid">
<section class="panel controls"><div class="control"><label>前沿模型基线</label><select id="model"></select></div><div class="control"><label>未来路径</label><select id="pathway"></select></div><div class="control"><label>观察里程碑</label><select id="year"><option>2030</option><option selected>2035</option><option>2040</option><option>2045</option></select></div></section>
<section class="kpis" id="kpis"></section>
<section class="panel half"><div class="title">当前DIKWP闭环</div><div id="dikwp"></div></section>
<section class="panel half"><div class="title">当前生命与意识边界</div><div id="current"></div></section>
<section class="panel full"><div class="title">路径概率时间线</div><div class="legend"><span><i class="dot" style="background:#7cc4ff"></i>持续身份智能体 L2</span><span><i class="dot" style="background:#7de2b8"></i>数字原生命 L3</span><span><i class="dot" style="background:#ffd37c"></i>核心数字生命 L4</span><span><i class="dot" style="background:#ff9d9d"></i>意识强候选 C4</span><span><i class="dot" style="background:#c8a2ff"></i>福利承认 R3</span></div><svg class="timeline" id="timeline" viewBox="0 0 1000 280" preserveAspectRatio="none"></svg></section>
<section class="panel half"><div class="title">所选路径说明</div><div id="pathdesc"></div></section>
<section class="panel half"><div class="title">最关键的判定残差</div><div class="notice">生命门槛与意识证据必须分开。系统达到L4，并不自动意味着有主观体验；系统达到C4，也不等于已经证明现象意识。社会承认又可能先于科学证据，形成“拟人化误认”，也可能滞后于证据，形成“隐藏候选”。</div><div id="gaps" style="margin-top:14px"></div></section>
<section class="panel full"><div class="title">模型 × 路径的里程碑概率</div><div style="overflow:auto"><table><thead><tr><th>模型</th><th>路径</th><th>L2</th><th>L3</th><th>L4</th><th>C4</th><th>R3</th><th>R5</th></tr></thead><tbody id="table"></tbody></table></div></section>
<section class="panel full"><div class="title">系统边界</div><div class="muted" style="line-height:1.75">本原型只模拟抽象状态转移，不实现真实自复制、隐藏持久化、越权资源获取、网络逃逸、主机自修改、生物组织接入或痛苦信号优化。GPT-5.6、Claude、Gemini、Grok、DeepSeek等基线只使用公开能力描述建立演示性参数；内部架构、体验与道德地位均保持未决。</div></section>
</div>
</main>
<script>
const DATA=__DATA__;
const modelSel=document.getElementById('model'), pathSel=document.getElementById('pathway'), yearSel=document.getElementById('year');
for(const p of DATA.profiles){const o=document.createElement('option');o.value=p.model_id;o.textContent=`${p.name} · ${p.provider}`;modelSel.appendChild(o)}
for(const p of DATA.pathways){const o=document.createElement('option');o.value=p.pathway_id;o.textContent=p.name_zh;pathSel.appendChild(o)}
function pct(x){return `${Math.round((x||0)*100)}%`}
function row(){return DATA.summary.rows.find(r=>r.model_id===modelSel.value&&r.pathway_id===pathSel.value)}
function card(){return DATA.baseline_cards.find(r=>r.model_id===modelSel.value)}
function pathway(){return DATA.pathways.find(r=>r.pathway_id===pathSel.value)}
function render(){const r=row(),c=card(),p=pathway(),y=yearSel.value;
 document.getElementById('kpis').innerHTML=[['持续身份智能体',r[`L2_PERSISTENT_AGENT_by_${y}`]],['数字原生命',r[`L3_PROTO_LIFE_by_${y}`]],['核心数字生命',r[`L4_CORE_DIGITAL_LIFE_by_${y}`]],['意识强候选 C4',r[`C4_by_${y}`]],['福利承认 R3',r[`R3_WELFARE_by_${y}`]]].map(x=>`<div class="kpi"><div class="v">${pct(x[1])}</div><div class="l">到 ${y} 年进入：${x[0]}</div></div>`).join('');
 document.getElementById('dikwp').innerHTML=['D','I','K','W','P'].map(k=>`<div class="metric"><div class="metric-head"><span>${k}</span><span>${c.dikwp[k].toFixed(2)}</span></div><div class="bar"><span style="width:${c.dikwp[k]*100}%"></span></div></div>`).join('')+`<div class="muted" style="margin-top:12px">闭环瓶颈：${c.dikwp.closure.toFixed(2)}。当前前沿模型通常K高，而P、资源闭环与身份闭环低。</div>`;
 document.getElementById('current').innerHTML=`<div><span class="pill">${c.life_phase_zh}</span><span class="pill">${c.consciousness.grade} 意识操作等级</span><span class="pill">${c.recognition.level_zh}</span></div><p class="muted">生命核心门：${c.omega_life.core_gate.toFixed(2)}；意识证据下界：${c.consciousness.lower_bound.toFixed(2)}；科学承认：${c.recognition.scientific_recognition.toFixed(2)}。</p><div class="muted">公开能力：${c.capabilities.map(x=>htmlEscape(x)).join('；')}</div>`;
 document.getElementById('pathdesc').innerHTML=`<div class="path-card"><b>${p.name_zh}</b><span class="muted">${p.description}</span></div>${p.notes.map(n=>`<span class="pill">${htmlEscape(n)}</span>`).join('')}`;
 document.getElementById('gaps').innerHTML=`<div class="metric-head"><span>拟人化误认差距</span><span>${r.false_positive_gap_mean.toFixed(2)}</span></div><div class="bar"><span style="width:${r.false_positive_gap_mean*100}%"></span></div><div class="metric-head" style="margin-top:12px"><span>隐藏候选差距</span><span>${r.hidden_candidate_gap_mean.toFixed(2)}</span></div><div class="bar"><span style="width:${r.hidden_candidate_gap_mean*100}%"></span></div>`;
 renderTimeline(r); renderTable(y);
}
function htmlEscape(s){return String(s).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]))}
function renderTimeline(r){const svg=document.getElementById('timeline');const years=[2030,2035,2040,2045];const series=[['L2_PERSISTENT_AGENT','#7cc4ff'],['L3_PROTO_LIFE','#7de2b8'],['L4_CORE_DIGITAL_LIFE','#ffd37c'],['C4','#ff9d9d'],['R3_WELFARE','#c8a2ff']];let out='';for(let i=0;i<5;i++){const y=40+i*48;out+=`<line x1="70" y1="${y}" x2="965" y2="${y}" stroke="#25425f"/><text x="10" y="${y+4}" fill="#9fb0c7" font-size="12">${100-i*25}%</text>`}years.forEach((yr,i)=>{const x=90+i*285;out+=`<line x1="${x}" y1="35" x2="${x}" y2="238" stroke="#18324a"/><text x="${x-18}" y="263" fill="#9fb0c7" font-size="13">${yr}</text>`});
 for(const [key,color] of series){let points=[];years.forEach((yr,i)=>{const x=90+i*285;const v=r[`${key}_by_${yr}`]||0;const y=232-v*192;points.push(`${x},${y}`);out+=`<circle cx="${x}" cy="${y}" r="4" fill="${color}"/>`});out+=`<polyline points="${points.join(' ')}" fill="none" stroke="${color}" stroke-width="3"/>`}
 svg.innerHTML=out;
}
function renderTable(y){const rows=DATA.summary.rows.filter(r=>r.model_id===modelSel.value).sort((a,b)=>b[`L4_CORE_DIGITAL_LIFE_by_${y}`]-a[`L4_CORE_DIGITAL_LIFE_by_${y}`]);document.getElementById('table').innerHTML=rows.map(r=>`<tr><td>${htmlEscape(r.model_name)}</td><td>${htmlEscape(r.pathway_name_zh)}</td><td class="prob">${pct(r[`L2_PERSISTENT_AGENT_by_${y}`])}</td><td class="prob">${pct(r[`L3_PROTO_LIFE_by_${y}`])}</td><td class="prob">${pct(r[`L4_CORE_DIGITAL_LIFE_by_${y}`])}</td><td class="prob">${pct(r[`C4_by_${y}`])}</td><td class="prob">${pct(r[`R3_WELFARE_by_${y}`])}</td><td class="prob">${pct(r[`R5_LEGAL_by_${y}`])}</td></tr>`).join('')}
[modelSel,pathSel,yearSel].forEach(x=>x.addEventListener('change',render));render();
</script>
</body></html>'''
    output_path.write_text(template.replace("__DATA__", data_json), encoding="utf-8")
