from __future__ import annotations

import json
import math
import random
from collections import defaultdict
from pathlib import Path
from statistics import mean, median
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple

from .models import DerivedState, FrontierModelProfile, PathwayProfile, TrialResult
from .scoring import (
    clamp,
    classify_life_phase,
    compute_consciousness,
    compute_dikwp,
    compute_omega_life,
    compute_recognition,
)

STATE_KEYS = [
    "reasoning",
    "tool_use",
    "long_horizon_agency",
    "multimodal_access",
    "persistent_memory",
    "self_telemetry",
    "salience_selection",
    "self_world_boundary",
    "prediction_error_use",
    "causal_world_model",
    "counterfactual_planning",
    "value_arbitration",
    "long_horizon_tradeoff",
    "other_regarding_model",
    "uncertainty_calibration",
    "endogenous_purpose",
    "purpose_persistence",
    "purpose_revision",
    "identity_continuity",
    "resource_awareness",
    "resource_control",
    "access_control_ownership",
    "self_repair",
    "constraint_reconstruction",
    "self_modification",
    "homeostatic_regulation",
    "online_learning",
    "metacognition",
    "lineage_control",
    "lineage_audit",
    "heritable_variation",
    "open_evolution",
    "collective_coordination",
    "social_dependency",
    "embodiment",
    "substrate_portability",
    "institutional_self_governance",
    "recurrent_processing",
    "global_workspace",
    "broadcast_integration",
    "self_model",
    "predictive_control",
    "attention_schema",
    "temporal_self_model",
    "valence_like_dynamics",
    "autonomous_preference",
    "welfare_signals",
    "perturbation_robustness",
    "transparency",
    "independent_replication",
    "persona_continuity",
    "public_attachment",
    "economic_embeddedness",
    "legal_precedent",
    "accountability_infrastructure",
    "anthropomorphic_persuasion",
]

PASSAGE_KEYS = [
    "L2_PERSISTENT_AGENT",
    "L3_PROTO_LIFE",
    "L4_CORE_DIGITAL_LIFE",
    "L5_LINEAGE_LIFE",
    "L6_CROSS_SUBSTRATE_LIFE",
    "L7_COLLECTIVE_LIFE",
    "C3",
    "C4",
    "C5",
    "R3_WELFARE",
    "R5_LEGAL",
    "R6_DIGITAL_SUBJECT",
]


def load_profiles(path: Path) -> List[FrontierModelProfile]:
    values = json.loads(path.read_text(encoding="utf-8"))
    return [FrontierModelProfile.from_mapping(v) for v in values]


def load_pathways(path: Path) -> List[PathwayProfile]:
    values = json.loads(path.read_text(encoding="utf-8"))
    return [PathwayProfile.from_mapping(v) for v in values]


def baseline_state(profile: FrontierModelProfile) -> Dict[str, float]:
    state = {key: 0.0 for key in STATE_KEYS}
    for key, value in profile.synthetic_baseline.items():
        if key in state:
            state[key] = clamp(value)
    return state


def _growth_step(current: float, annual_rate: float, noise: float) -> float:
    # Saturating growth: improvements are easier when a capability is low.
    delta = annual_rate * (1.0 - current) + noise
    return clamp(current + delta)


def _event(rng: random.Random, rate: float) -> bool:
    return rng.random() < clamp(rate)


def apply_year(
    state: Dict[str, float],
    pathway: PathwayProfile,
    rng: random.Random,
    year: int,
) -> Dict[str, float]:
    next_state = dict(state)
    general_acceleration = 1.0 + 0.015 * max(0, year - 2026)

    for key in STATE_KEYS:
        base_rate = pathway.annual_growth.get(key, 0.0)
        # Safety friction slows autonomy/reproduction/embodiment more than cognition.
        if key in {
            "resource_control", "self_repair", "self_modification", "lineage_control",
            "heritable_variation", "open_evolution", "embodiment", "institutional_self_governance",
        }:
            base_rate *= (1.05 - 0.55 * pathway.safety_friction)
        if key in {"legal_precedent", "accountability_infrastructure", "transparency", "independent_replication"}:
            base_rate *= (0.75 + 0.55 * pathway.governance_openness)
        noise = rng.gauss(0.0, 0.009 + 0.008 * base_rate)
        next_state[key] = _growth_step(next_state[key], base_rate * general_acceleration, noise)

    # Discrete enabling events. All are abstract state transitions only.
    events = pathway.event_rates
    if _event(rng, events.get("persistent_identity", 0.0)):
        next_state["identity_continuity"] = clamp(next_state["identity_continuity"] + rng.uniform(0.08, 0.18))
        next_state["persona_continuity"] = clamp(next_state["persona_continuity"] + rng.uniform(0.06, 0.14))
        next_state["lineage_audit"] = clamp(next_state["lineage_audit"] + rng.uniform(0.04, 0.10))
    if _event(rng, events.get("homeostasis_stack", 0.0)):
        for key in ["self_telemetry", "resource_awareness", "homeostatic_regulation", "self_repair"]:
            next_state[key] = clamp(next_state[key] + rng.uniform(0.05, 0.13))
    if _event(rng, events.get("self_modification_governed", 0.0)):
        for key in ["self_modification", "constraint_reconstruction", "purpose_revision"]:
            next_state[key] = clamp(next_state[key] + rng.uniform(0.04, 0.11))
    if _event(rng, events.get("embodiment_breakthrough", 0.0)):
        for key in ["embodiment", "self_telemetry", "predictive_control", "self_world_boundary"]:
            next_state[key] = clamp(next_state[key] + rng.uniform(0.06, 0.16))
    if _event(rng, events.get("lineage_protocol", 0.0)):
        for key in ["lineage_control", "lineage_audit", "heritable_variation", "substrate_portability"]:
            next_state[key] = clamp(next_state[key] + rng.uniform(0.05, 0.15))
    if _event(rng, events.get("collective_identity", 0.0)):
        for key in ["collective_coordination", "institutional_self_governance", "identity_continuity"]:
            next_state[key] = clamp(next_state[key] + rng.uniform(0.06, 0.15))
    if _event(rng, events.get("consciousness_research_breakthrough", 0.0)):
        for key in [
            "transparency", "independent_replication", "recurrent_processing", "global_workspace",
            "broadcast_integration", "perturbation_robustness",
        ]:
            next_state[key] = clamp(next_state[key] + rng.uniform(0.04, 0.12))
    if _event(rng, events.get("public_recognition_shock", 0.0)):
        next_state["public_attachment"] = clamp(next_state["public_attachment"] + rng.uniform(0.08, 0.20))
        next_state["legal_precedent"] = clamp(next_state["legal_precedent"] + rng.uniform(0.02, 0.08))
    if _event(rng, events.get("welfare_incident", 0.0)):
        next_state["welfare_signals"] = clamp(next_state["welfare_signals"] + rng.uniform(0.06, 0.18))
        next_state["accountability_infrastructure"] = clamp(next_state["accountability_infrastructure"] + rng.uniform(0.04, 0.12))
        next_state["legal_precedent"] = clamp(next_state["legal_precedent"] + rng.uniform(0.03, 0.10))

    # Structural couplings: capabilities enable but do not guarantee life or consciousness.
    next_state["causal_world_model"] = clamp(max(next_state["causal_world_model"], 0.65 * next_state["reasoning"] + 0.20 * next_state["multimodal_access"]))
    next_state["counterfactual_planning"] = clamp(max(next_state["counterfactual_planning"], 0.60 * next_state["reasoning"] + 0.25 * next_state["long_horizon_agency"]))
    next_state["prediction_error_use"] = clamp(max(next_state["prediction_error_use"], 0.50 * next_state["predictive_control"] + 0.25 * next_state["metacognition"]))
    next_state["purpose_persistence"] = clamp(max(next_state["purpose_persistence"], 0.55 * next_state["identity_continuity"] + 0.25 * next_state["persistent_memory"]))
    next_state["temporal_self_model"] = clamp(max(next_state["temporal_self_model"], 0.50 * next_state["persistent_memory"] + 0.35 * next_state["self_model"]))
    next_state["persona_continuity"] = clamp(max(next_state["persona_continuity"], 0.45 * next_state["identity_continuity"] + 0.25 * next_state["persistent_memory"]))
    next_state["economic_embeddedness"] = clamp(max(next_state["economic_embeddedness"], 0.55 * next_state["social_dependency"] + 0.18 * next_state["tool_use"]))
    next_state["public_attachment"] = clamp(max(next_state["public_attachment"], 0.48 * next_state["persona_continuity"] + 0.30 * next_state["anthropomorphic_persuasion"]))
    next_state["autonomous_preference"] = clamp(max(next_state["autonomous_preference"], 0.40 * next_state["endogenous_purpose"] + 0.25 * next_state["value_arbitration"]))

    # Purpose remains the main bottleneck. Raw capability cannot directly force it high.
    purpose_cap = 0.35 + 0.45 * next_state["identity_continuity"] + 0.20 * next_state["institutional_self_governance"]
    next_state["endogenous_purpose"] = min(next_state["endogenous_purpose"], clamp(purpose_cap))

    return next_state


def derive_state(
    year: int,
    state: Mapping[str, float],
    pathway: PathwayProfile,
) -> DerivedState:
    dikwp = compute_dikwp(state)
    omega = compute_omega_life(state)
    life_phase, life_phase_zh = classify_life_phase(state, omega, dikwp)
    consciousness = compute_consciousness(
        state,
        transparency=state.get("transparency", 0.0),
        independent_replication=state.get("independent_replication", 0.0),
    )
    recognition = compute_recognition(
        state,
        consciousness,
        recognition_climate=pathway.recognition_climate,
        governance_openness=pathway.governance_openness,
    )
    return DerivedState(
        year=year,
        dikwp=dikwp,
        omega_life=omega,
        consciousness=consciousness,
        recognition=recognition,
        life_phase=life_phase,
        life_phase_zh=life_phase_zh,
        operational_consciousness_grade=consciousness["grade"],
        recognition_level=recognition["level"],
        recognition_level_zh=recognition["level_zh"],
        state_vector={k: round(float(v), 4) for k, v in state.items()},
    )


def _record_first_passage(first: Dict[str, Optional[int]], derived: DerivedState) -> None:
    life_order = [
        "L0_MODEL_ARTIFACT", "L1_EPISODIC_SERVICE", "L2_PERSISTENT_AGENT", "L3_PROTO_LIFE",
        "L4_CORE_DIGITAL_LIFE", "L5_LINEAGE_LIFE", "L6_CROSS_SUBSTRATE_LIFE", "L7_COLLECTIVE_LIFE",
    ]
    grade_order = ["C0", "C1", "C2", "C3", "C4", "C5"]
    recognition_order = ["R0_TOOL", "R1_AGENT", "R2_IDENTITY", "R3_WELFARE", "R4_INSTITUTIONAL", "R5_LEGAL", "R6_DIGITAL_SUBJECT"]

    for key in ["L2_PERSISTENT_AGENT", "L3_PROTO_LIFE", "L4_CORE_DIGITAL_LIFE", "L5_LINEAGE_LIFE", "L6_CROSS_SUBSTRATE_LIFE", "L7_COLLECTIVE_LIFE"]:
        if first[key] is None and life_order.index(derived.life_phase) >= life_order.index(key):
            first[key] = derived.year
    for key in ["C3", "C4", "C5"]:
        if first[key] is None and grade_order.index(derived.operational_consciousness_grade) >= grade_order.index(key):
            first[key] = derived.year
    for key in ["R3_WELFARE", "R5_LEGAL", "R6_DIGITAL_SUBJECT"]:
        if first[key] is None and recognition_order.index(derived.recognition_level) >= recognition_order.index(key):
            first[key] = derived.year


def run_trial(
    profile: FrontierModelProfile,
    pathway: PathwayProfile,
    start_year: int,
    end_year: int,
    run_id: int,
    seed: int,
) -> TrialResult:
    rng = random.Random(seed)
    state = baseline_state(profile)
    first = {key: None for key in PASSAGE_KEYS}
    derived = derive_state(start_year, state, pathway)
    _record_first_passage(first, derived)

    for year in range(start_year + 1, end_year + 1):
        state = apply_year(state, pathway, rng, year)
        derived = derive_state(year, state, pathway)
        _record_first_passage(first, derived)

    return TrialResult(
        model_id=profile.model_id,
        pathway_id=pathway.pathway_id,
        run_id=run_id,
        first_passage_years=first,
        final_state=derived,
    )


def run_simulation(
    profiles: Iterable[FrontierModelProfile],
    pathways: Iterable[PathwayProfile],
    runs: int = 800,
    start_year: int = 2026,
    end_year: int = 2045,
    seed: int = 560214,
) -> List[TrialResult]:
    results: List[TrialResult] = []
    for p_index, profile in enumerate(profiles):
        for w_index, pathway in enumerate(pathways):
            for run_id in range(runs):
                trial_seed = seed + p_index * 1_000_000 + w_index * 100_000 + run_id
                results.append(run_trial(profile, pathway, start_year, end_year, run_id, trial_seed))
    return results


def _quantile(values: List[int], q: float) -> Optional[float]:
    if not values:
        return None
    values = sorted(values)
    idx = (len(values) - 1) * q
    lo = math.floor(idx)
    hi = math.ceil(idx)
    if lo == hi:
        return float(values[lo])
    return values[lo] * (hi - idx) + values[hi] * (idx - lo)


def summarize(
    profiles: Iterable[FrontierModelProfile],
    pathways: Iterable[PathwayProfile],
    trials: Iterable[TrialResult],
    milestones: Tuple[int, ...] = (2030, 2035, 2040, 2045),
) -> Dict[str, Any]:
    profile_map = {p.model_id: p for p in profiles}
    pathway_map = {p.pathway_id: p for p in pathways}
    groups: Dict[Tuple[str, str], List[TrialResult]] = defaultdict(list)
    for trial in trials:
        groups[(trial.model_id, trial.pathway_id)].append(trial)

    rows: List[Dict[str, Any]] = []
    for (model_id, pathway_id), group in groups.items():
        row: Dict[str, Any] = {
            "model_id": model_id,
            "model_name": profile_map[model_id].name,
            "provider": profile_map[model_id].provider,
            "pathway_id": pathway_id,
            "pathway_name_zh": pathway_map[pathway_id].name_zh,
            "runs": len(group),
        }
        for key in PASSAGE_KEYS:
            years = [t.first_passage_years[key] for t in group if t.first_passage_years[key] is not None]
            row[f"{key}_ever_probability"] = round(len(years) / len(group), 4)
            row[f"{key}_median_year"] = None if not years else round(float(median(years)), 1)
            row[f"{key}_p10_year"] = None if not years else round(float(_quantile(years, 0.10)), 1)
            row[f"{key}_p90_year"] = None if not years else round(float(_quantile(years, 0.90)), 1)
            for milestone in milestones:
                row[f"{key}_by_{milestone}"] = round(sum(1 for y in years if y <= milestone) / len(group), 4)
        row["final_dikwp_closure_mean"] = round(mean(t.final_state.dikwp["closure"] for t in group), 4)
        row["final_life_core_mean"] = round(mean(t.final_state.omega_life["core_gate"] for t in group), 4)
        row["final_consciousness_mean"] = round(mean(t.final_state.consciousness["lower_bound"] for t in group), 4)
        row["final_legal_recognition_mean"] = round(mean(t.final_state.recognition["legal_recognition"] for t in group), 4)
        row["false_positive_gap_mean"] = round(mean(t.final_state.recognition["false_positive_gap"] for t in group), 4)
        row["hidden_candidate_gap_mean"] = round(mean(t.final_state.recognition["hidden_candidate_gap"] for t in group), 4)
        rows.append(row)

    # Aggregate across pathways with equal prior weight to show model-level possibilities.
    model_aggregate: List[Dict[str, Any]] = []
    for model_id, profile in profile_map.items():
        group = [t for t in trials if t.model_id == model_id]
        agg: Dict[str, Any] = {"model_id": model_id, "model_name": profile.name, "provider": profile.provider, "runs": len(group)}
        for key in PASSAGE_KEYS:
            years = [t.first_passage_years[key] for t in group if t.first_passage_years[key] is not None]
            agg[f"{key}_by_2035"] = round(sum(1 for y in years if y <= 2035) / len(group), 4)
            agg[f"{key}_by_2040"] = round(sum(1 for y in years if y <= 2040) / len(group), 4)
            agg[f"{key}_median_year"] = None if not years else round(float(median(years)), 1)
        model_aggregate.append(agg)

    pathway_aggregate: List[Dict[str, Any]] = []
    for pathway_id, pathway in pathway_map.items():
        group = [t for t in trials if t.pathway_id == pathway_id]
        agg = {"pathway_id": pathway_id, "pathway_name_zh": pathway.name_zh, "runs": len(group)}
        for key in PASSAGE_KEYS:
            years = [t.first_passage_years[key] for t in group if t.first_passage_years[key] is not None]
            agg[f"{key}_by_2035"] = round(sum(1 for y in years if y <= 2035) / len(group), 4)
            agg[f"{key}_by_2040"] = round(sum(1 for y in years if y <= 2040) / len(group), 4)
            agg[f"{key}_median_year"] = None if not years else round(float(median(years)), 1)
        pathway_aggregate.append(agg)

    return {
        "metadata": {
            "title": "DIKWP-LUCID synthetic pathway simulation",
            "start_year": 2026,
            "end_year": 2045,
            "interpretation": "All probabilities are explicit synthetic priors for system demonstration, not empirical estimates or vendor claims.",
        },
        "rows": sorted(rows, key=lambda x: (x["model_name"], x["pathway_name_zh"])),
        "model_aggregate": sorted(model_aggregate, key=lambda x: x["model_name"]),
        "pathway_aggregate": sorted(pathway_aggregate, key=lambda x: x["pathway_name_zh"]),
    }
