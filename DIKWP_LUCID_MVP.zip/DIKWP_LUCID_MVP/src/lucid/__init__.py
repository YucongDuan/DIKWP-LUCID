"""DIKWP-LUCID: synthetic frontier-AI lifeform and consciousness-recognition simulator."""

__all__ = [
    "models",
    "scoring",
    "simulation",
    "dashboard",
]

__version__ = "0.1.0"
