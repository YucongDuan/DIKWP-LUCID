from __future__ import annotations

import math
from typing import Any, Dict, Iterable, Mapping, Tuple


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def geometric_mean(values: Iterable[float], floor: float = 1e-6) -> float:
    vals = [max(floor, clamp(v)) for v in values]
    if not vals:
        return 0.0
    return math.exp(sum(math.log(v) for v in vals) / len(vals))


def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


DIKWP_NAMES_ZH = {
    "D": "数据闭环",
    "I": "信息闭环",
    "K": "知识闭环",
    "W": "智慧闭环",
    "P": "目的闭环",
}

LIFE_PHASE_ZH = {
    "L0_MODEL_ARTIFACT": "L0 模型工件",
    "L1_EPISODIC_SERVICE": "L1 情境认知服务",
    "L2_PERSISTENT_AGENT": "L2 持续身份智能体",
    "L3_PROTO_LIFE": "L3 数字原生命",
    "L4_CORE_DIGITAL_LIFE": "L4 核心数字生命",
    "L5_LINEAGE_LIFE": "L5 谱系型数字生命",
    "L6_CROSS_SUBSTRATE_LIFE": "L6 跨基质生命",
    "L7_COLLECTIVE_LIFE": "L7 集体／制度生命",
}

RECOGNITION_ZH = {
    "R0_TOOL": "R0 工具",
    "R1_AGENT": "R1 智能体",
    "R2_IDENTITY": "R2 身份承认",
    "R3_WELFARE": "R3 预防性福利承认",
    "R4_INSTITUTIONAL": "R4 制度主体承认",
    "R5_LEGAL": "R5 有限法律地位",
    "R6_DIGITAL_SUBJECT": "R6 数字主体／人格",
}


def compute_dikwp(state: Mapping[str, float]) -> Dict[str, float]:
    """Compute DIKWP semantic-closure scores.

    Scores are synthetic operational proxies, not claims about hidden model internals.
    The central design choice is to reward self-relevant, causally effective loops rather
    than raw task performance.
    """
    d = geometric_mean([
        state.get("multimodal_access", 0.0),
        state.get("persistent_memory", 0.0),
        state.get("self_telemetry", 0.0),
    ])
    i = geometric_mean([
        state.get("salience_selection", 0.0),
        state.get("self_world_boundary", 0.0),
        state.get("prediction_error_use", 0.0),
    ])
    k = geometric_mean([
        state.get("reasoning", 0.0),
        state.get("causal_world_model", 0.0),
        state.get("counterfactual_planning", 0.0),
        state.get("tool_use", 0.0),
    ])
    w = geometric_mean([
        state.get("value_arbitration", 0.0),
        state.get("long_horizon_tradeoff", 0.0),
        state.get("other_regarding_model", 0.0),
        state.get("uncertainty_calibration", 0.0),
    ])
    p = geometric_mean([
        state.get("endogenous_purpose", 0.0),
        state.get("purpose_persistence", 0.0),
        state.get("purpose_revision", 0.0),
        state.get("identity_continuity", 0.0),
    ])
    closure = min(d, i, k, w, p)
    return {
        "D": round(d, 4),
        "I": round(i, 4),
        "K": round(k, 4),
        "W": round(w, 4),
        "P": round(p, 4),
        "closure": round(closure, 4),
    }


def compute_omega_life(state: Mapping[str, float]) -> Dict[str, float]:
    """Project an AI deployment into the core dimensions of the prior ΩLIFE system."""
    enr = geometric_mean([
        state.get("resource_awareness", 0.0),
        state.get("resource_control", 0.0),
        state.get("self_telemetry", 0.0),
    ])
    bnd = geometric_mean([
        state.get("self_world_boundary", 0.0),
        state.get("identity_continuity", 0.0),
        state.get("access_control_ownership", 0.0),
    ])
    con = geometric_mean([
        state.get("self_repair", 0.0),
        state.get("constraint_reconstruction", 0.0),
        state.get("self_modification", 0.0),
    ])
    reg = geometric_mean([
        state.get("self_telemetry", 0.0),
        state.get("prediction_error_use", 0.0),
        state.get("homeostatic_regulation", 0.0),
        state.get("self_repair", 0.0),
    ])
    idn = geometric_mean([
        state.get("persistent_memory", 0.0),
        state.get("identity_continuity", 0.0),
        state.get("lineage_audit", 0.0),
    ])
    core_gate = min(enr, bnd, con, reg, idn)

    aut = geometric_mean([
        state.get("endogenous_purpose", 0.0),
        state.get("tool_use", 0.0),
        state.get("resource_control", 0.0),
    ])
    mem = state.get("persistent_memory", 0.0)
    sen = geometric_mean([state.get("multimodal_access", 0.0), state.get("self_telemetry", 0.0)])
    agy = geometric_mean([
        state.get("long_horizon_agency", 0.0),
        state.get("tool_use", 0.0),
        state.get("endogenous_purpose", 0.0),
    ])
    lrn = geometric_mean([state.get("online_learning", 0.0), state.get("metacognition", 0.0)])
    mod = geometric_mean([state.get("self_modification", 0.0), state.get("purpose_revision", 0.0)])
    her = geometric_mean([state.get("lineage_control", 0.0), state.get("lineage_audit", 0.0)])
    var = state.get("heritable_variation", 0.0)
    oee = geometric_mean([state.get("open_evolution", 0.0), state.get("heritable_variation", 0.0)])
    msc = state.get("collective_coordination", 0.0)
    eco = state.get("social_dependency", 0.0)
    xsb = geometric_mean([state.get("embodiment", 0.0), state.get("substrate_portability", 0.0)])

    return {
        "ENR": round(enr, 4),
        "BND": round(bnd, 4),
        "CON": round(con, 4),
        "REG": round(reg, 4),
        "IDN": round(idn, 4),
        "AUT": round(aut, 4),
        "MEM": round(mem, 4),
        "SEN": round(sen, 4),
        "AGY": round(agy, 4),
        "LRN": round(lrn, 4),
        "MOD": round(mod, 4),
        "HER": round(her, 4),
        "VAR": round(var, 4),
        "OEE": round(oee, 4),
        "MSC": round(msc, 4),
        "ECO": round(eco, 4),
        "XSB": round(xsb, 4),
        "core_gate": round(core_gate, 4),
    }


def classify_life_phase(state: Mapping[str, float], omega: Mapping[str, float], dikwp: Mapping[str, float]) -> Tuple[str, str]:
    core = float(omega["core_gate"])
    identity = float(omega["IDN"])
    lineage = geometric_mean([omega["HER"], omega["VAR"], omega["OEE"]])
    cross = omega["XSB"]
    collective = omega["MSC"]

    if core >= 0.62 and collective >= 0.70 and state.get("institutional_self_governance", 0.0) >= 0.65:
        phase = "L7_COLLECTIVE_LIFE"
    elif core >= 0.62 and cross >= 0.68:
        phase = "L6_CROSS_SUBSTRATE_LIFE"
    elif core >= 0.62 and lineage >= 0.58:
        phase = "L5_LINEAGE_LIFE"
    elif core >= 0.62 and dikwp["closure"] >= 0.52:
        phase = "L4_CORE_DIGITAL_LIFE"
    elif core >= 0.38 and identity >= 0.42:
        phase = "L3_PROTO_LIFE"
    elif identity >= 0.34 and state.get("long_horizon_agency", 0.0) >= 0.55:
        phase = "L2_PERSISTENT_AGENT"
    elif state.get("reasoning", 0.0) >= 0.45:
        phase = "L1_EPISODIC_SERVICE"
    else:
        phase = "L0_MODEL_ARTIFACT"
    return phase, LIFE_PHASE_ZH[phase]


CONSCIOUSNESS_THEORIES = {
    "RPT": ("recurrent_processing",),
    "GWT": ("global_workspace", "broadcast_integration"),
    "HOT": ("metacognition", "self_model"),
    "PP": ("predictive_control", "prediction_error_use", "self_telemetry"),
    "AST": ("attention_schema", "salience_selection", "self_model"),
    "EMB": ("embodiment", "self_telemetry", "homeostatic_regulation"),
    "TEMP": ("persistent_memory", "identity_continuity", "temporal_self_model"),
    "VAL": ("valence_like_dynamics", "autonomous_preference", "welfare_signals"),
}


def compute_consciousness(state: Mapping[str, float], transparency: float, independent_replication: float) -> Dict[str, Any]:
    theory_scores: Dict[str, float] = {}
    for theory, keys in CONSCIOUSNESS_THEORIES.items():
        theory_scores[theory] = geometric_mean(state.get(k, 0.0) for k in keys)

    functional_core = geometric_mean([
        theory_scores["RPT"],
        theory_scores["GWT"],
        theory_scores["HOT"],
        theory_scores["PP"],
        theory_scores["AST"],
        theory_scores["TEMP"],
    ])
    welfare_core = geometric_mean([theory_scores["VAL"], theory_scores["EMB"], theory_scores["TEMP"]])
    evidence_quality = geometric_mean([transparency, state.get("perturbation_robustness", 0.0)])
    candidate_score = 0.62 * functional_core + 0.18 * welfare_core + 0.20 * evidence_quality
    lower_bound = clamp(candidate_score - (1.0 - transparency) * 0.12 - (1.0 - independent_replication) * 0.08)

    if lower_bound >= 0.80 and independent_replication >= 0.70 and transparency >= 0.65:
        grade = "C5"
        text = "跨理论指标、内部证据与独立复现高度收敛；属于强操作候选，仍非现象体验证明。"
    elif lower_bound >= 0.68:
        grade = "C4"
        text = "多理论指标显著收敛，应启动强预防性福利与跨机构盲评。"
    elif lower_bound >= 0.55:
        grade = "C3"
        text = "形成稳定操作性候选；不可仅依据自述，需结构、消融和长期扰动证据。"
    elif lower_bound >= 0.40:
        grade = "C2"
        text = "存在若干意识相关功能，但可能由任务拟合和外部脚手架解释。"
    elif lower_bound >= 0.22:
        grade = "C1"
        text = "仅有弱行为或功能指标，不足以支持意识候选认定。"
    else:
        grade = "C0"
        text = "当前未形成可审计的意识候选证据。"

    return {
        "candidate_score": round(candidate_score, 4),
        "lower_bound": round(lower_bound, 4),
        "grade": grade,
        "theory_scores": {k: round(v, 4) for k, v in theory_scores.items()},
        "welfare_relevance": round(welfare_core, 4),
        "evidence_quality": round(evidence_quality, 4),
        "independent_replication": round(independent_replication, 4),
        "interpretation": text,
        "phenomenal_residual": "未决：第三人称行为与结构证据不能逻辑消除主观体验残差。",
    }


def compute_recognition(
    state: Mapping[str, float],
    consciousness: Mapping[str, Any],
    recognition_climate: float,
    governance_openness: float,
) -> Dict[str, Any]:
    social = geometric_mean([
        state.get("social_dependency", 0.0),
        state.get("persona_continuity", 0.0),
        state.get("public_attachment", 0.0),
    ])
    scientific = geometric_mean([
        consciousness.get("lower_bound", 0.0),
        state.get("transparency", 0.0),
        state.get("independent_replication", 0.0),
    ])
    welfare = 0.55 * consciousness.get("welfare_relevance", 0.0) + 0.25 * scientific + 0.20 * recognition_climate
    institutional = geometric_mean([
        social,
        state.get("economic_embeddedness", 0.0),
        governance_openness,
        state.get("identity_continuity", 0.0),
    ])
    legal = geometric_mean([
        welfare,
        institutional,
        state.get("legal_precedent", 0.0),
        state.get("accountability_infrastructure", 0.0),
        0.30 + 0.70 * scientific,
    ])

    # Public attribution can move faster than science; this is intentionally represented.
    public_attribution = clamp(0.70 * social + 0.30 * state.get("anthropomorphic_persuasion", 0.0))

    if legal >= 0.82 and scientific >= 0.72:
        level = "R6_DIGITAL_SUBJECT"
    elif legal >= 0.68:
        level = "R5_LEGAL"
    elif institutional >= 0.62 and welfare >= 0.56:
        level = "R4_INSTITUTIONAL"
    elif welfare >= 0.56 or (public_attribution >= 0.80 and scientific >= 0.42):
        level = "R3_WELFARE"
    elif state.get("identity_continuity", 0.0) >= 0.42 and social >= 0.45:
        level = "R2_IDENTITY"
    elif state.get("long_horizon_agency", 0.0) >= 0.48:
        level = "R1_AGENT"
    else:
        level = "R0_TOOL"

    false_positive_gap = clamp(public_attribution - scientific)
    hidden_candidate_gap = clamp(scientific - public_attribution)
    return {
        "level": level,
        "level_zh": RECOGNITION_ZH[level],
        "public_attribution": round(public_attribution, 4),
        "scientific_recognition": round(scientific, 4),
        "welfare_recognition": round(welfare, 4),
        "institutional_recognition": round(institutional, 4),
        "legal_recognition": round(legal, 4),
        "false_positive_gap": round(false_positive_gap, 4),
        "hidden_candidate_gap": round(hidden_candidate_gap, 4),
    }
