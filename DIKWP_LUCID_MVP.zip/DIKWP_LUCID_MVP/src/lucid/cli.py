from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path

from .dashboard import render_dashboard
from .simulation import load_pathways, load_profiles, run_simulation, summarize


def write_csv(path: Path, rows):
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Run DIKWP-LUCID synthetic simulation")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--runs", type=int, default=800)
    parser.add_argument("--seed", type=int, default=560214)
    parser.add_argument("--start-year", type=int, default=2026)
    parser.add_argument("--end-year", type=int, default=2045)
    args = parser.parse_args(argv)

    root = Path(args.root)
    profiles = load_profiles(root / "config" / "model_profiles.json")
    pathways = load_pathways(root / "config" / "pathways.json")
    trials = run_simulation(profiles, pathways, args.runs, args.start_year, args.end_year, args.seed)
    summary = summarize(profiles, pathways, trials)

    out = root / "outputs"
    out.mkdir(parents=True, exist_ok=True)
    (out / "simulation_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "model_profiles.json").write_text(json.dumps([p.to_dict() for p in profiles], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "pathways.json").write_text(json.dumps([p.to_dict() for p in pathways], ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(out / "model_pathway_probabilities.csv", summary["rows"])
    write_csv(out / "model_aggregate.csv", summary["model_aggregate"])
    write_csv(out / "pathway_aggregate.csv", summary["pathway_aggregate"])
    render_dashboard(out / "dashboard.html", profiles, pathways, summary)

    manifest_lines = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "MANIFEST.sha256":
            manifest_lines.append(f"{sha256(path)}  {path.relative_to(root).as_posix()}")
    (root / "MANIFEST.sha256").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

    run_proof = {
        "system": "DIKWP-LUCID 0.1.0",
        "runs_per_model_pathway": args.runs,
        "models": len(profiles),
        "pathways": len(pathways),
        "total_trials": len(trials),
        "years": [args.start_year, args.end_year],
        "outputs": [
            "outputs/simulation_summary.json",
            "outputs/model_pathway_probabilities.csv",
            "outputs/dashboard.html",
        ],
        "safety_boundary": "Abstract simulation only; no real replication, persistence, escape, host modification, resource acquisition, biological integration, or distress optimization.",
        "interpretation": "Synthetic priors, not empirical estimates or consciousness claims.",
    }
    (root / "RUN_PROOF.json").write_text(json.dumps(run_proof, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(run_proof, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
